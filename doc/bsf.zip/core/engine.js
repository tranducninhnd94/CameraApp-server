var BotSailBase = require(global.appRoot + "/core/botsailbase.js");
var Topics = require(global.appRoot + "/app/models/entities/topic.js");
var Common = require(global.appRoot + "/core/common.js");

class Engine extends BotSailBase {
	query(data) {

	}

	setRes(res) {
		this.res = res;
	}

	setReq(req) {
		this.req = req;
	}

	async getTopicValueListName(topicName, language) {
		let result = null;
		let obj = {
			"name": topicName
		}

		if(Common.isset(lang)) obj["language"] = language;

		try {
			result = await Topics.find(obj);
			if(Common.isset(result.items)) return Object.keys(result.items);
			return null;
		} catch (ex) {
			console.dir(ex);
		}

		return null;
	}


	async getTopicValueListDataAll(topicName, language) {
		let result = null;
		let obj = {
			"name": topicName
		}

		if(Common.isset(lang)) obj["language"] = language;

		try {
			result = await Topics.find(obj);
		} catch (ex) {
			console.dir(ex);
		}

		return result;
	}

	async getTopicNextItem(topicName, data, language) {
		let result = null;
		let obj = {
			"name": topicName
		}

		if(Common.isset(language)) obj["language"] = language;

		try {
			result = await Topics.find(obj);
			if((Common.isset(result) == null) || (result.length == 0)) return null;
			result = result[0];
			let keys = Object.keys(result.items);
			let currKeys = Object.keys(data);

			for(let index in keys) {
				let valueName = keys[index];
				let bool = true;
				for(let index1 in currKeys) {
					if(valueName == currKeys[index1]) bool = false;
				}

				if(bool == true) return result.items[valueName];
			}
		} catch (ex) {
			console.dir(ex);
		}

		return null;
	}

	async getRandomNextQuestion(topicName, data, language) {
		let nextValue = await this.getTopicNextItem(topicName, data, language);
		if(nextValue == null)  return null;
		let length = nextValue.length - 1;
		let r = Math.floor(Math.random() * length) + 1;

		return nextValue[r];
	}

	//Lấy field value trong DB, kết hợp với pattern để lấy được key_value
	getItemValue(item) {
		if(!Common.isset(item)) return null;


		if(Common.isset(item.callback)) {
			var callback_value = null;
			eval(item.callback);
			let obj = {
					"name" : item.name,
					"value" :  callback_value
				}
			return obj;
		}

		return null;
	}

	async isFullItemValues(topicName, data, language) {
		let obj = getTopicNextItem(topicName, data, language);
		if(!Common.isset(obj))
			return true;

		return false;
	}
	
}

module.exports = Engine;