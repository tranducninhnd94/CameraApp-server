var BotSailBase = require(global.appRoot + "/core/botsailbase.js");
var Topics = require(global.appRoot + "/app/models/entities/topic.js");
var Common = require(global.appRoot + "/core/common.js");

class Plugin extends BotSailBase {
	
	
}

module.exports = Plugin;